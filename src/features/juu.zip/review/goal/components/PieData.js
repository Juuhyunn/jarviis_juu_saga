// export default [

const PieData = [
    {
      id: "추천을 사용함",
      label: "추천을 사용함",
      value: 554,
      color: "hsl(174, 70%, 50%)"
    },
    {
      id: "추천을 수정함",
      label: "추천을 수정함",
      value: 214,
      color: "hsl(207, 70%, 50%)"
    },
    {
      id: "추천을 거절함",
      label: "추천을 거절함",
      value: 57,
      color: "hsl(115, 70%, 50%)"
    },
    {
      id: "안뇽",
      label: "안뇽",
      value: 21,
      color: "hsl(115, 70%, 50%)"
    }
  ];
export default PieData